import java.util.List;

public interface Pagamento {

	double calcularTotal();

}

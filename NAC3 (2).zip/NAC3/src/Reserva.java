import java.util.List;

public class Reserva implements Pagamento {
	private Cliente cliente;
	private int modelo;
	private boolean pagamentoAvista;

	public Reserva(Cliente cliente, int modelo, boolean pagamentoAvista) {
		super();
		this.cliente = cliente;
		this.modelo = modelo;
		this.pagamentoAvista = pagamentoAvista;

	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public int getModelo() {
		return modelo;
	}

	public void setModelo(int modelo) {
		this.modelo = modelo;
	}

	public boolean isPagamentoAvista() {
		return pagamentoAvista;
	}

	public void setPagamentoAvista(boolean pagamentoAvista) {
		this.pagamentoAvista = pagamentoAvista;
	}

	public String toString() {
		String aux = "";

		aux += "Cliente: " + cliente + "\n";
		aux += "Modelo: " + modelo + "\n";
		aux += "Pre�o do Modelo--> R$" + calcularTotal() + "\n";
		aux += "Pagamento a Vista? " + (pagamentoAvista == true ? "SIM" : "N�O") + "\n";

		return aux;
	}

	public double calcularTotal() {

		double total = 0;

		if (modelo == 1)
			total += 3000;
		else if (modelo == 2)
			total += 3000;
		else
			total += 3000;

		if (pagamentoAvista == true) {
			total *= 1.10;
		}
		return total;
	}

	
}

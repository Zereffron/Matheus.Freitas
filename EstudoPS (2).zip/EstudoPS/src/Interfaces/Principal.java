package Interfaces;

import static javax.swing.JOptionPane.*;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Integer.parseInt;
import Metodos.Metodos;
import heranca.*;

public class Principal {

	public static void main(String[] args) {
		int opcao = 0;
		
		List<Pessoa> listap= new ArrayList<>();
		List<Medico> listam= new ArrayList<>();
		

		do {
			opcao = parseInt(showInputDialog(Metodos.menu()));
			try {
				if (opcao < 1 || opcao > 7) {
					throw new OpcaoInvalidaException("A op��o deve estar entre 1 e 7!");
				}

				switch (opcao) {
				case 1:
					Metodos.registrarPaciente(listap);
					break;
				case 2:
					Metodos.registrarMedico(listap);
					break;
				case 3:
					Metodos.registarCurriculum(listam);
					break;
				case 4:
					Metodos.pesquisar(listap);
					break;
				case 5:
					Metodos.listar(listap);
					break;
				case 6:
					Metodos.demitirMedico(listap);
					break;
				case 7:
					break;

				}

			} catch (OpcaoInvalidaException e) {
				showMessageDialog(null, e);
			}

		} while (opcao != 7);
	}

}

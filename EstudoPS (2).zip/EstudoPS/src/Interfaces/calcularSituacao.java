package Interfaces;

public interface calcularSituacao {
	double calcularPesoIdeal();
	double calcularIMC();
	String calcularSituacao();

}

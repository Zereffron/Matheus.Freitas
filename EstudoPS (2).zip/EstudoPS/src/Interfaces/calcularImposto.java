package Interfaces;

public interface calcularImposto {
	double calcularImposto();

}

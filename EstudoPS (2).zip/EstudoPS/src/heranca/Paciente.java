package heranca;

import Interfaces.calcularSituacao;

public class Paciente extends Pessoa implements calcularSituacao {
	private double pesoAtual;
	private double altura;
	private String genero;

	public Paciente(String nome, double pesoAtual, double altura, String genero) {
		super(nome);
		this.pesoAtual = pesoAtual;
		this.altura = altura;
		this.genero = genero;
	}

	public String toString() {
		String aux = super.toString();
		aux += "Peso Atual(KG):" + pesoAtual + "\n";
		aux += "Peso Ideal" + calcularPesoIdeal() + "\n";
		aux += "IMC:" + calcularIMC() + "\n";
		aux += "Situa��o:" + calcularSituacao() + "\n";
		aux += "Altura:(M.cm)" + altura + "\n";
		aux += "G�nero:" + genero + "\n";

		return aux;
	}

	@Override
	public double calcularPesoIdeal() {
		double pi = 0;
		if (genero.equalsIgnoreCase("h")) {
			pi = 62.1 * altura - 58;

		} else {
			pi = 72.7 * altura - 44.7;
		}

		return pi;

	}

	@Override
	public double calcularIMC() {
		double imc = 0;

		imc = pesoAtual / Math.pow(altura, 2);

		return imc;
	}

	@Override
	public String calcularSituacao() {
		double situacao = calcularIMC();

		String aux = "";

		if (situacao <= 18.4) {
			aux += "Abaixo do Peso!";
		} else if (situacao <= 24.9) {
			aux += "Peso Normal";
		} else if (situacao <= 29.9) {
			aux += "Sobre Peso";
		} else if (situacao <= 34.9) {
			aux += "Obesidade 1� Grau";
		} else if (situacao <= 39.9) {
			aux += "Obesidade 2� Grau";
		} else {
			aux += "Obesidade 3� Grau";
		}
		return aux;
	}

}

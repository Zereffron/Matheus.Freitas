package heranca;
import Interfaces.calcularImposto;

public class Medico extends Pessoa implements calcularImposto {
	private String especialidade;
	private double rendaAnual;

	public Medico(String nome, String especialidade, double rendaAnual) {
		super(nome);
		this.especialidade = especialidade;
		this.rendaAnual = rendaAnual;
	}

	public Medico(String nome, String especialidade) {
		super(nome);
		this.especialidade = especialidade;

	}

	@Override
	public double calcularImposto() {
		double ir = 0;

		if (rendaAnual <= 21453.24) {
			System.out.println("ISENTO DE IR!");

		} else if (rendaAnual <= 32151.48) {
			ir = (rendaAnual - 1608.99) * 7.5 / 100;
		} else if (rendaAnual <= 42869.16) {
			ir = (rendaAnual - 1608.99) * 15 / 100;

		} else if (rendaAnual <= 53565.72) {
			ir = (rendaAnual - 1608.99) * 22.5 / 100;
		} else {
			ir = (rendaAnual - 1608.99) * 27.5 / 100;
		}
		return ir;
	}
	
	public String toString() {
		String aux=super.toString();
		aux+="Especialidade"+especialidade+"\n";
		aux+="Renda Anual(R$):"+especialidade+"\n";
		aux+="Imposto de Renda:"+calcularImposto()+"\n";
		
		return aux;
		
	}

}

package Metodos;

import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;
import static java.lang.Double.*;

import java.util.ArrayList;
import java.util.List;

import heranca.*;

public class Metodos {

	public static String menu() {
		String aux = "";
		aux += "Clinica\n" + "1.Registrar Paciente\n" + "2.Registrar Medico\n" + "3.Registrar Curricaulum do Medico\n"
				+ "4.Pesquisar Paciente\n" + "5.Listar Pacientes e Medicos\n" + "6.Demitir Medico\n" + "7.Sair";

		return aux;
	}

	public static void registrarPaciente(List<Pessoa> listap) {
		String nome = "";
		double pesoAtual = 0;
		double altura = 0;
		String genero = "";
		Pessoa paciente;

		nome = showInputDialog("Nome do Paciente:");
		pesoAtual = Double.parseDouble(showInputDialog("Peso Atual do Paciente:"));
		altura = Double.parseDouble(showInputDialog("Altura do Paciente:"));
		genero = showInputDialog("Informe o G�nero do Paciente(H-Homem M-Mulher):");

		paciente = new Paciente(nome, pesoAtual, altura, genero);

		listap.add(paciente);

	}

	public static void registrarMedico(List<Pessoa> listap) {
		String nome = "";
		String especialidade = "";
		double rendaAnual = 0;
		Medico medico;

		nome = showInputDialog("Nome do Paciente:");
		especialidade = showInputDialog("Especialidade do Medico:");
		rendaAnual = Double.parseDouble(showInputDialog("Renda Anual do Paciente:"));

		medico = new Medico(nome, especialidade, rendaAnual);

		listap.add(medico);

	}
	public static void registarCurriculum(List<Medico> listam){
		String nome;
		String especialidade;
		Medico curriculo;
		
		nome=showInputDialog("Nome do Medico:");
		especialidade=showInputDialog("Especialidade de medico");
		
		curriculo=new Medico(nome,especialidade);
		
		listam.add(curriculo);
		
	}

	public static void listar(List<Pessoa> listap) {
		String aux = "";

		aux += "----Medicos----\n";
		for (Pessoa pessoa : listap) {
			if (pessoa instanceof Medico) {
				aux += pessoa;
			}

		}
		aux += "----Pacientes----\n";
		for (Pessoa pessoa : listap) {
			if (pessoa instanceof Paciente) {
				aux += pessoa;
			}

		}

		showMessageDialog(null, aux);

	}
}

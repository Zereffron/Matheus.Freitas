package heranca;

public abstract class Pessoa {

	private String nome;

	public Pessoa(String nome) {
		super();
		this.nome = nome;
	}

	@Override
	public String toString() {
		String aux ="";
		
		aux+="Nome:"+nome+"\n";
		
		return aux;
	}

	
}

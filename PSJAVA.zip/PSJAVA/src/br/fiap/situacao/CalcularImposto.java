package br.fiap.situacao;

public abstract interface CalcularImposto {
	
	public double calcularImposto();
}

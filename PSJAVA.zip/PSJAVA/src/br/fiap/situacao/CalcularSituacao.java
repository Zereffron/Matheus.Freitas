package br.fiap.situacao;

public abstract interface CalcularSituacao {
	
	public double calcularPesoIdeal();
	
	public double calcularIMC();
	
	public String calcularSituacao();
}

package br.fiap.pessoa;

public abstract class Pessoa {
	
		private String nome;

		public Pessoa(String nome) {
			super();
			this.nome = nome;
		}

		@Override
		public String toString() {
			String aux = "";
			aux += "Nome : "+nome;
			return aux;
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		
		
		
}

package br.fiap.pessoa;

import br.fiap.situacao.CalcularSituacao;

public class Paciente extends Pessoa implements CalcularSituacao{
	
	private double pesoAtual;
	private double altura;
	private String genero;
	
	public Paciente(String nome, double pesoAtual, double altura, String genero) {
		super(nome);
		this.pesoAtual = pesoAtual;
		this.altura = altura;
		this.genero = genero;
	}
	
	@Override
	public double calcularPesoIdeal() {
		double pesoIdeal =0;
		
		if(genero.equalsIgnoreCase("h")){
			pesoIdeal = 72.7*altura-58;
		}
		else{
			pesoIdeal = 62.1*altura-44.7;
		}
		
		return pesoIdeal;
	}

	@Override
	public double calcularIMC() {
		double imc;
		
		imc = pesoAtual /(altura*altura);
		
		return imc;
	}

	@Override
	public String calcularSituacao() {
		
		double situacao = calcularIMC();
		
		String aux = "";
		
		if(situacao <= 18.4){
			aux += "Abaixo do peso";
		}
		else if(situacao >= 18.5 && situacao <= 24.9){
			aux += "Peso Normal";
		}
		else if(situacao >= 25 && situacao <= 29.9){
			aux += "Sobrepeso";
		}
		else if(situacao >= 30 && situacao <= 34.9){
			aux += "Obesidade Grau I";
		}
		else if(situacao >= 35 && situacao <= 39.9){
			aux += "Obesidade Grau II";
		}
		else if(situacao >= 40){
			aux += "Obesidade Grau III";
		}
		return aux;
	}
	

	public double getPesoAtual() {
		return pesoAtual;
	}

	public void setPesoAtual(double pesoAtual) {
		this.pesoAtual = pesoAtual;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	
	
	
}

package br.fiap.pessoa;

import br.fiap.situacao.CalcularImposto;

public class Medico extends Pessoa implements CalcularImposto {

	private String especialidade;
	private double rendaAnual;

	public Medico(String nome, String especialidade) {
		this(nome, especialidade, 0);
	}

	public Medico(String nome, String especialidade, double rendaAnual) {
		super(nome);
		this.especialidade = especialidade;
		this.rendaAnual = rendaAnual;
	}

	@Override
	public double calcularImposto() {
		double aliquota;
		double parcela;
		double ir = 0;

		if (rendaAnual <= 21453.24) {
			ir = (rendaAnual - 1608.99) * 7.5 / 100;
		} else if (rendaAnual >= 21453.25 && rendaAnual <= 32151.48) {
			ir = (rendaAnual - 4020.35) * 15 / 100;
		} else if (rendaAnual >= 32151.49 && rendaAnual <= 42869.16) {
			ir = (rendaAnual - 7235.54) * 22.5 / 100;
		} else if (rendaAnual >= 53565.72) {
			ir = (rendaAnual - 9913.83) * 27.5 / 100;
		}
		return ir;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}

	public double getRendaAnual() {
		return rendaAnual;
	}

	public void setRendaAnual(double rendaAnual) {
		this.rendaAnual = rendaAnual;
	}

}

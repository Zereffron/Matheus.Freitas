package br.fiap.principal;
import static java.lang.Integer.*;
import static javax.swing.JOptionPane.*;
import java.util.ArrayList;
import java.util.List;

import br.fiap.dao.ContaDAO;
import br.fiap.excecao.OpcaoInvalidaException;
import br.fiap.pessoa.Medico;
import br.fiap.pessoa.Pessoa;

public class Principal {

	public static void main(String[] args) {
		
		List<Pessoa> lista = new ArrayList<>();
		List<Medico> listaM = new ArrayList<>();
		
		int op =0 ;
		
		do{
			try {
				op = parseInt(showInputDialog(getMenu()));
				if(op < 1 || op > 7){
					throw new OpcaoInvalidaException("Informe um valor entre 1 e 7");					
				}
				switch(op){
					case 1: ContaDAO.registrarpaciente(lista);
					break;
					
					case 2: ContaDAO.registrarmedico(lista);
					break;
				
					case 3: ContaDAO.curriculum(lista,listaM);
					break;
				
					case 4: ContaDAO.pesquisar(lista);
					break;
					
					case 5: ContaDAO.listar(lista);
					break;
				
				}
				
			} catch (OpcaoInvalidaException e) {
				showMessageDialog(null, e);
			} catch (NumberFormatException e ){
				showMessageDialog(null, "Opc�o Inv�lida");
			}
		}while(op != 7);
	}
	
	
	public static String getMenu(){
		String aux = "";
		aux += ">>>>>>>>> Clinica Medica - SAUDE MAIS <<<<<<<<<<\n";
		aux += "1. Registrar paciente\n";
		aux += "2. Registrar medico\n";
		aux += "3. Registrar curriculum de medico\n";
		aux += "4. Pesquisar paciente\n";
		aux += "5. Listar pacientes e m�dicos\n";
		aux += "6. Demitir medico\n";
		aux += "7. Sair\n";
		return aux;
	}

}

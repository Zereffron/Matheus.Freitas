package br.fiap.excecao;

public class OpcaoInvalidaException extends Exception{
	
	public OpcaoInvalidaException(String msg){
		super(msg);
	}
}

package br.fiap.dao;
import static java.lang.Double.*;
import static java.lang.Integer.*;
import static javax.swing.JOptionPane.*;
import java.util.List;

import br.fiap.pessoa.Medico;
import br.fiap.pessoa.Paciente;
import br.fiap.pessoa.Pessoa;

public class ContaDAO {

	public static void registrarpaciente(List<Pessoa> lista) {
		
		Pessoa pessoa;
		String nome; 
		double pesoAtual;
		double altura;
		String genero;
		
		nome = showInputDialog("Informe o nome do paciente: ");
		genero = showInputDialog("Informe H para homem ou M para mulher: ");
		pesoAtual = parseDouble(showInputDialog("Informe o peso atual do paciente: "));
		altura = parseDouble(showInputDialog("Informe a altura do paciente: "));
		
		pessoa = new Paciente(nome, pesoAtual, altura, genero);
		
		lista.add(pessoa);
	}

	public static void registrarmedico(List<Pessoa> lista) {
		
		Pessoa pessoa;
		String nome;
		String especialidade;
		double rendaAtual;
		
		nome = showInputDialog("Informe o nome do m�dico: ");
		especialidade = showInputDialog("Informe a especialidade do m�dico: ");
		rendaAtual = parseDouble(showInputDialog("Informe a renda atual do m�dico: "));
		
		pessoa = new Medico(nome, especialidade, rendaAtual);
		
		lista.add(pessoa);
	}

	public static void curriculum(List<Pessoa> lista, List<Medico> listaM) {
		String nome;
		String especialidade;
		Medico medico;
		
		nome = showInputDialog("Informe o nome do m�dico para curriculum : ");
		especialidade = showInputDialog("Informe a especialidae do m�dico para curriculum : ");
		
		medico = new Medico(nome, especialidade);
		
		listaM.add(medico);
	}
	
	public static Pessoa pesquisaraux(List<Pessoa> lista) {
			Pessoa pesquisa = null;
			String nome;
			
			nome = showInputDialog("Informe o nome do paciente para pesquisa: ");
			
			for (Pessoa pessoa : lista) {
				if(nome.equalsIgnoreCase(pessoa.getNome())){
					pesquisa = pessoa;
					break;
				}
			}
		return pesquisa;
	}

	public static void pesquisar(List<Pessoa> lista) {
	
		Pessoa auxiliar = pesquisaraux(lista);
		
		String aux = "";
		
		if(auxiliar == null){
			aux += "Paciente n�o encontrado";
		}
		else{
			aux += "Nome: "+auxiliar.getNome()+"\n";
			aux += "Peso: "+((Paciente) auxiliar).getPesoAtual()+"\n";
			aux += "Altura: "+((Paciente)auxiliar).getAltura()+"\n";
			aux += "Genero: "+((Paciente)auxiliar).getGenero()+"\n";		
		}
		showMessageDialog(null, aux);
	}

	public static void listar(List<Pessoa> lista) {
		
		String aux = "";
		
		aux += ">> M�dicos << \n";
		for (Pessoa pessoa : lista) {
			
			if(pessoa instanceof Medico){
				aux += "Nome: "+pessoa.getNome()+"\n";
				aux += "Especialidade: "+((Medico) pessoa).getEspecialidade()+"\n";
				aux += "Renda Atual: R$"+((Medico)pessoa).getRendaAnual()+"\n";
				
			}
		}
		
		aux += ">> Pacientes << \n";
		for (Pessoa pessoa : lista) {
			
			if(pessoa instanceof Paciente){
				aux += "Nome: "+pessoa.getNome()+"\n";
				aux += "Peso atual: "+((Paciente) pessoa).getPesoAtual()+"\n";
				aux += "Altura: "+((Paciente) pessoa).getAltura()+"\n";
				aux += "Genero: "+((Paciente) pessoa).getGenero()+"\n";
			}
		}
		showMessageDialog(null, aux);
	}

	

}


public abstract class Cliente {
  String nome;

public Cliente(String nome) {
	super();
	this.nome = nome;
}
  
  public String toString() {
	  String aux="";
	  aux+="Nome: "+nome+"\n";
	  
	  return aux;
  }
}


public class Reserva implements Pagamento {
	Cliente cliente;
	int modelo;
	boolean pagamentoAvista;
	
	public Reserva(Cliente cliente, int modelo, boolean pagamentoAvista) {
		super();
		this.cliente = cliente;
		this.modelo = modelo;
		this.pagamentoAvista = pagamentoAvista;
	}
	
	public String toString() {
		String aux="";
		
		aux+="Cliente: "+cliente+"\n";
		aux+="Modelo: "+modelo+"\n";
		aux+="Pagamento a Vista? "+pagamentoAvista+"\n";
		
		
		
		return aux;
	}

	@Override
	public double calcularTotal() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}


import java.util.ArrayList;
import java.util.List;


import static javax.swing.JOptionPane.*;

public class Principal {

	public static void main(String[] args) {

		List<Cliente> lista = new ArrayList<>();
		int opcao = 0;

		do {
			try {
				opcao = Integer.parseInt(showInputDialog(Menu()));
				if (opcao < 1 || opcao > 6) {
					throw new ValorInvalidoException("A Op��o deve estar entre 1 a 6!");
				} else {
					switch (opcao) {
					case 1:
						cadastrar(lista);

						break;
					case 2:
						imprimir(lista);

						break;
					case 3:
						pesquisarAux(lista);

						break;
					case 4:

						break;
					case 5:

						break;
					case 6:

						break;

					}
				}
			} catch (ValorInvalidoException e) {
				showMessageDialog(null, e);

			}

		} while (opcao != 6);

	}

	private static void cadastrar(List<Reserva> lista) {
		String opcao = "";
		

		opcao = showInputDialog("Informe o Tipo de Pessoa a Cadastrar(F-Fisica J-Juridica)");
		if (opcao.equalsIgnoreCase("F")) {

			PessoaFisica pf = new PessoaFisica();
			Reserva rr=new Reserva(new PessoaFisica(showInputDialog("Nome"), showInputDialog("CPF")),showInputDialog("Modelo:"),showInputDialog("Pagamento a Vista?"));
			lista.add(pf);

		} else if (opcao.equalsIgnoreCase("J")) {

			PessoaJuridica pj = new PessoaJuridica(showInputDialog("Nome"), showInputDialog("CNPJ"));
			lista.add(pj);

		}

	}

	private static void imprimir(List<Cliente> lista) {
		String auxpf = "--------Pessoa Fisica--------\n";
		String auxpj = "--------Pessoa Juridica--------\n";

		for (Cliente cli : lista) {
			if (cli instanceof PessoaFisica) {
				auxpf += cli.toString();

			} else if (cli instanceof PessoaJuridica) {
				auxpj += cli.toString();
			}
			showMessageDialog(null, auxpf + "\n" + auxpj);

		}
	}

	private static Cliente pesquisarAux(List<Cliente> lista) {
		Cliente aux = null;

		String cpf_cnpj = showInputDialog("Informe o CPF/CNPJ");

		for (Cliente p : lista) {
			if (p instanceof PessoaFisica) {
				if (((PessoaFisica) p).getCpf().equalsIgnoreCase(cpf_cnpj)) {
					aux = p;
					break;
				}
			}

			else if (p instanceof PessoaJuridica) {
				if (((PessoaJuridica) p).getCnpj().equalsIgnoreCase(cpf_cnpj)) {
					aux = p;
					break;
				}
			}

		}
		return aux;
	}

	public static String Menu() {
		String aux = "Opera��es\n" + "1.Reservar Carro\n" + "2.Pesquisar Reservas\n" + "3.Imprimir Reservas\n"
				+ "4.Imprimir lista de espera\n" + "5.Cancelar Reserva\n" + "6.Finalizar";
		return aux;
	}

}

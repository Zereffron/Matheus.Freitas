
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import static javax.swing.JOptionPane.*;

public class Principal {

	public static void main(String[] args) {

		List<Reserva> lista = new ArrayList<>();

		int opcao = 0;

		do {
			try {
				opcao = Integer.parseInt(showInputDialog(Menu()));
				if (opcao < 1 || opcao > 6) {
					throw new ValorInvalidoException("A Op��o deve estar entre 1 a 6!");
				} else {
					switch (opcao) {
					case 1:
						cadastrar(lista);

						break;
					case 2:
						pesquisar(lista);

						break;
					case 3:
						imprimir(lista);

						break;
					case 4:

						break;
					case 5:

						break;
					case 6:

						break;

					}
				}
			} catch (ValorInvalidoException e) {
				showMessageDialog(null, e);

			}

		} while (opcao != 6);

	}

	private static void cadastrar(List<Reserva> lista) {
		String opcao = "";

		opcao = showInputDialog("Informe o Tipo de Pessoa a Cadastrar(F-Fisica J-Juridica)");
		if (opcao.equalsIgnoreCase("F")) {

			Reserva rr = new Reserva(new PessoaFisica(showInputDialog("Nome"), showInputDialog("CPF:")),
					Integer.parseInt(showInputDialog("Modelo:"))

					, (showConfirmDialog(null, "Pagamento a Vista?", null, JOptionPane.YES_NO_OPTION)) == 0);

			lista.add(rr);

		} else if (opcao.equalsIgnoreCase("J")) {

		}

	}

	private static void pesquisar(List<Reserva> lista) {
		Reserva aux = pesquisarAux(lista);

		if (aux == null) {
			showMessageDialog(null, "CPF/CNPJ n�o encontrado !!");
		} else {
			showMessageDialog(null, aux);
		}

	}

	private static Reserva pesquisarAux(List<Reserva> lista) {
		Reserva aux = null;

		String cpf_cnpj = showInputDialog("Informe o CPF/CNPJ");

		for (Reserva cli : lista) {
			if (cli instanceof Reserva) {
				if (cli.getCliente() instanceof PessoaFisica) {
					((PessoaFisica) cli.getCliente()).getCpf().equals(cpf_cnpj);
					aux = cli;
					break;
				} else if (cli.getCliente() instanceof PessoaJuridica) {
					((PessoaJuridica) cli.getCliente()).getCnpj().equals(cpf_cnpj);
					aux = cli;
					break;
				}

			}

		}

		return aux;
	}

	private static void imprimir(List<Reserva> lista) {
		String auxpf = "--------Clientes--------\n";

		for (Reserva cli : lista) {
			if (cli instanceof Reserva) {
				auxpf += cli;

			}

		}
		showMessageDialog(null, auxpf + "\n");
	}

	public static String Menu() {
		String aux = "Opera��es\n" + "1.Reservar Carro\n" + "2.Pesquisar Reservas\n" + "3.Imprimir Reservas\n"
				+ "4.Imprimir lista de espera\n" + "5.Cancelar Reserva\n" + "6.Finalizar";
		return aux;
	}

}


public interface Pagamento {

	double calcularTotal();

}
